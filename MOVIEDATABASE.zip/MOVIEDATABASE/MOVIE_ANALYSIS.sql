1//.Which is the movie which has collected the highest revenue?
select movie_title as Name,max(revenue)as highest_revenue from movie_tb
where revenue=(select max(revenue) from movie_tb)
group by movie_title;

//2.which film has low vote?//
select movie_title as Name,min(vote_average)as vote from movie_tb
where vote_average=(select min(vote_average) from movie_tb)
group by movie_title;

// 3.Top 5 Fiction movies which have collected highest revenue
select m.movie_title as Title ,r.revenue as Revenue, m.genres____ as Genres from movie_tb m join 
movie_tb r on m.movie_id=r.movie_id
where m.genres____ like '%Fiction%'
order by revenue desc
fetch first 5 rows only;

// 4.find out the 10 directors name who have directed action films and earned highest revenue// 
select m.movie_title as TITLE ,r.movie_director as Director_Name,r.revenue as Revenue from movie_tb m join movie_tb r on
m.movie_id=r.movie_id  
where m.genres____ like '%Action%' order by r.revenue desc
fetch first 10 rows only;
�
//5. From the database list the Names of the director and no'of films directed more than 15 films//
select movie_director,count(movie_director)as Total_movies_directed from movie_tb group by movie_director
having count(movie_director)>=15
order by count(movie_director) desc;
//6.List the movie_title directed by Steven Spielberg//
select movie_director,movie_title from movie_tb
where movie_director='Steven Spielberg'
ORDER BY MOVIE_TITLE ASC;

//7.What kind of genres of the movie has highest vote//
select genres____,vote_average from movie_tb
where vote_average=(select max(vote_average)from movie_tb);

//8.list the 5 movie names which has budgetlower than the revenue earned //
select movie_title as Movie_Name,movie_budget as budget_of_the_movie,revenue as Revenue_collected from movie_tb
where revenue>movie_budget
order by movie_budget desc
fetch first 5 rows only;

//9. From the database list the Names of the cast acted in more than 3 films together//
select movie_cast,count(movie_cast)as Total_movies_acted from movie_tb group by movie_cast
having count(movie_cast)>=3
order by count(movie_cast) desc;

//10. list the movie names which contains "Star Trek"//
select movie_title from movie_tb
where movie_title like 'Star Trek%';

//11. list the movie names released between 2015 to 2022 and collected highest revenue//
select movie_title,release_date,revenue as Revenue_collected from movie_tb
where release_date between '01-01-2015'and '01-01-2022'
order by MOVIE_TITLE,RELEASE_DATE ASC;

//12.list of the movies produced by Paramount Pictures//
select m.movie_title,r.production_companies__ from movie_tb m join movie_tb r
on m.movie_id=r.movie_id
where r.Production_companies__ like '%Paramount Pictures__%'
ORDER BY MOVIE_TITLE;
